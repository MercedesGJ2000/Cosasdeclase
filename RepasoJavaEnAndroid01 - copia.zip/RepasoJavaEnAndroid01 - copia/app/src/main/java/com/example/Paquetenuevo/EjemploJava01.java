package com.example.Paquetenuevo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class EjemploJava01 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       TextView textView = (TextView) findViewById(R.id.TextView);
        /*textView.setText("Declaración e inicialización de variables");
        int i = 123;
        double x = 0.5123;
        double y = 1.0;
        double a = 123.0;
        double b = 3.1416E-10;
        char c = 'a';
        boolean v = true;
        String p ="Esto es una cadena";
        textView.append("\ni=" + i);
        textView.append("\nx="+x + ",y="+y);
        textView.append("\na="+a+",b="+b);
        textView.append("\ncarácter=" + c);
        textView.append("\nEsFalso="+v);
        textView.append("\ncadena="+p);
*/
     /*  textView.setText("Operaciones aritméticas");
       double a = 2.0;
       double b = 3.0;
       double x = 74.0;
       int i = 1;
       textView.append(a +" + " + b + " = " + (a+b));
        textView.append(a +" - " + b + " = " + (a-b));
        textView.append(a +" * " + b + " = " + (a*b));
        textView.append(a +" /" + b + " = " + (a/b));
        textView.append(x +" / " + b + " = " + (x/b));
        i++;
        textView.append("\ni incrementado en uno = " + i);
        i--;
        textView.append("\ni decrementado en uno = " + i);

        textView.append("\nOperaciones con tipos distintos");
        textView.append("\n" +x +" + " + i +" = " + (double)(x+i));
        textView.append("\n"+x +" + " + i +" = " + (int)(x+i));

        textView.append("\nResultado de operación compuesta \nz= " + ((x*(a + i) / (x * x + 1) - 1 / a) * (i - x)/a));*/



     /*  textView.setText("Operaciones de variables");
       textView.append("\nConversión de int a float a double");
       int i = 125;
       double x = 12.3456789;
       textView.append("\ni=" + i+ "\nx=" + (float)i + "\nd=" + (double)i);
       textView.append("\nConversión de double a float a int");
       textView.append("\nd=" + x + "\nx = " + (float)x + "\ni = "+ (int)i );
    */
     /*
     double x = Math.PI;
     double y = -1.0;

     textView.setText("x = " + x );
     textView.append("\ny = "+y);
     textView.append("\nValor absoluto = " + Math.abs(y));
     textView.append("\nRaíz cuadrada de x = " + Math.sqrt(x));
     textView.append("\nLogaritmo de x = " + Math.log(x));
     textView.append("\nExponencial (x) = "+ Math.exp(x));
     textView.append("\nx al cubo = " + Math.pow(x, 3));
     textView.append("\nCoseno de x = " + Math.cos(x));
     textView.append("\nSeno de x = " + Math.sin(x));
     textView.append("\nTangente (x) = " + Math.tan(x));
     textView.append("\nArcocoseno(y) = " + Math.acos(y));
     textView.append("\nArcoseno (y) = " + Math.asin(y));
     textView.append("\nArcotangente (y) = " + Math.atan(y));
     textView.append("\nMaximo de x e y = " + Math.max(x,y));
     textView.append("\nEl resto entre x e y es = "+ (x%y));
     textView.append("\nExpresado en grados x = " + Math.toDegrees(x));
     textView.append("\nExpresado en radiantes y = " + Math.toRadians(y));*/
/*
     double x = Math.random()*2;
     textView.setText("Números aleatorios y métodos de redondeo");
     textView.append("\nUn número aleatorio entre 0 y 2 \nx = " +x ) ;
     textView.append("\nceil(x)" + Math.ceil(x));
     textView.append("\nfloor(x) = "+ Math.floor(x));
     textView.append("\nround(x) = " + Math.round(x));

     textView.append("\nRedondeos hasta cualquier cifra decimal");
     textView.append("\nredondeado a la segunda cifra "  + Math.round(x * Math.pow(10,2)) / Math.pow(10,2));
     textView.append("\nredondeado a la tercera cifra "  + Math.round(x * Math.pow(10,3)) / Math.pow(10,3));
     textView.append("\nredondeado a la cuarta cifra "  + Math.round(x * Math.pow(10,4)) / Math.pow(10,4));
     textView.append("\nredondeado a la quinta cifra "  + Math.round(x * Math.pow(10,5)) / Math.pow(10,5));
*/

    double x = 2.0;
    double y  = 3.0;
    textView.setText("Bloque If-Else\n");
    if (x < y){
        textView.append(x + " < " + y);
    }else {
        textView.append(x + " > " + y);
    }
    textView.append("\nOperadores booleanos");
    boolean h = true;
    boolean c = true;
    if (2.0 > 1){
        h = true;
    }else {
        h = false;
    }if( 3.0 < 10){
        c = true;
        }else{
        c = false;

        }
    textView.append("\ncondición1 es : " + h);
    textView.append("\ncondicion2 es : " + c);
    textView.append("\nLas dos son true simulatenamente si " + x + " >" + 1 + " y " + y + " < " + 10);
    }
}
